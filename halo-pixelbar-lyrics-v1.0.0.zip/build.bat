@echo off
REM 构建 花再 Halo PixelBar 歌词投射 exe
cd /d %~dp0
pip install --disable-pip-version-check hidapi requests websocket-client pyinstaller
pyinstaller --noconfirm --onefile --windowed --name 花再HaloPixelBar歌词投射 main.py
echo.
echo 构建完成: dist\花再HaloPixelBar歌词投射.exe
pause
