# -*- coding: utf-8 -*-
"""
歌词显示引擎：轮询 CDP 歌词 → 分页 → 按时间戳调度推送到像素屏。
支持设备端布局动画与软件端逐帧动画，带下一句预推、间奏钳制、长句分页。
"""
from __future__ import annotations

import collections
import heapq
import threading
import time

from animations import (BOUNCE_MAX_UNITS, gen_frames, is_device_animation,
                        layout_for)
from halo_device import HaloDevice, display_units

CAPACITY_UNITS = 16.0          # 屏宽容量（全角=1单位，半角=0.5）
SPLIT_CHARS = set(" 　，。、！？!?,.·—…（）()\"\"'")
INTERLUDE_FACTOR = 3.0
STATIC_MAX_HOLD_MS = 3000
BASE_HOLD_MS = 700
PER_CHAR_HOLD_MS = 90
PAGE_MIN_HOLD_MS = 600
PAGE_MAX_HOLD_MS = 1200
POLL_INTERVAL = 0.04           # 轮询间隔（秒）
PRE_PUSH_WINDOW_MS = 6000      # 预推允许提前的最长窗口

# 歌词元信息行（作词/作曲/编曲等），不推上屏幕
METADATA_PREFIXES = ("作词", "作曲", "编曲", "制作人", "混音", "录音", "和声", "监制",
                     "出品", "OP", "SP", "原唱", "翻唱", "词曲", "制作", "发行", "企划")
METADATA_MAX_LEN = 16


def is_metadata_line(text: str) -> bool:
    t = text.strip()
    if not t or len(t) > METADATA_MAX_LEN:
        return False
    head = t.replace("：", ":").replace(" ", "")
    for pre in METADATA_PREFIXES:
        if head.startswith(pre) or head.startswith(pre + ":"):
            return True
    return False


def split_lyric_pages(text: str, capacity: float = CAPACITY_UNITS):
    """长句按屏宽分页：每页 ≤ capacity 单位；优先在空格/标点处切分，避免孤字尾页。"""
    pages = []
    remaining = text
    while display_units(remaining) > capacity and len(remaining) > 1:
        chars_fit = 0
        acc = 0.0
        for ch in remaining:
            acc += 1.0 if ord(ch) >= 0x2E80 else 0.5
            if acc > capacity:
                break
            chars_fit += 1
        if chars_fit < 1:
            chars_fit = 1
        target_char = min((len(remaining) + 1) // 2, chars_fit)
        best = -1
        for offset in range(0, 8):
            candidates = [target_char] if offset == 0 else [target_char - offset, target_char + offset]
            for pos in candidates:
                if 0 < pos < len(remaining) and remaining[pos - 1] in SPLIT_CHARS:
                    best = pos
                    break
            if best >= 0:
                break
        if best < 0 or best >= len(remaining):
            best = target_char
        pages.append(remaining[:best].rstrip())
        remaining = remaining[best:].lstrip()
    if remaining:
        pages.append(remaining)
    return pages


def estimate_hold_ms(text: str) -> int:
    units = display_units(text)
    if units <= CAPACITY_UNITS:
        return min(STATIC_MAX_HOLD_MS, BASE_HOLD_MS + PER_CHAR_HOLD_MS * len(text))
    return min(8000, 900 + int(260 * units))


class EngineConfig:
    def __init__(self, animation="center", color=(0xF0, 0xB4, 0xC8), lead_ms=350):
        self.animation = animation
        self.color = color
        self.lead_ms = lead_ms


class LyricEngine(threading.Thread):
    def __init__(self, device: HaloDevice, source, config: EngineConfig,
                 log=None, on_lyric=None):
        super().__init__(daemon=True)
        self.device = device
        self.source = source
        self.config = config
        self.log = log or (lambda msg: None)
        self.on_lyric = on_lyric or (lambda text: None)
        self._stop = threading.Event()
        self._events = []          # [(due_ms, seq, kind, payload)]
        self._seq = 0
        self._current = None
        self._prepushed_text = None
        self._prepushed_at = 0.0
        self._song_start = 0.0
        self._song_samples = collections.deque(maxlen=6)
        self._layout_sent = None
        self._color_sent = None

    # ---------- 控制 ----------
    def stop(self):
        self._stop.set()

    # ---------- 事件队列 ----------
    def _push_event(self, due_ms, kind, payload):
        self._seq += 1
        heapq.heappush(self._events, (due_ms, self._seq, kind, payload))

    def _drain_events(self, now_ms):
        fired = []
        while self._events and self._events[0][0] <= now_ms:
            fired.append(heapq.heappop(self._events))
        for due, _seq, kind, payload in fired:
            try:
                self._execute(kind, payload, due)
            except Exception as exc:
                self.log("[错误] 事件执行失败 %s: %s" % (kind, exc))

    def _execute(self, kind, payload, due):
        if kind == "layout":
            self._send_layout(payload)
        elif kind == "text":
            self.device.set_text(payload)
            self.on_lyric(payload)
        elif kind == "frames":
            text, end_ms, anim = payload
            for off, frame_text in gen_frames(text, end_ms - due, anim):
                self._push_event(due + off, "text", frame_text)
        elif kind == "prepush":
            text = payload
            now_ms = time.time() * 1000.0
            # 迟到守卫：预推时刻已过太久（暂停/拖动进度等）则放弃，避免字幕抢跑
            if now_ms - due > 1000:
                return
            self._prepushed_text = text
            self._prepushed_at = now_ms
            self._send_layout(layout_for(self.config.animation))
            self.device.set_text(text)
            self.on_lyric(text)

    def _send_layout(self, layout):
        if layout != self._layout_sent:
            self.device.set_layout(layout, self.config.color)
            self._layout_sent = layout

    def _ensure_color(self):
        if self._color_sent != self.config.color:
            self.device.set_color(self.config.color)
            self._color_sent = self.config.color

    # ---------- 歌词调度 ----------
    def _on_line(self, d):
        now_ms = time.time() * 1000.0
        text = (d.text or "").strip()
        if not text:
            return

        # 元信息行（作词/作曲等）不上屏，跳过调度但记录当前行避免重复处理
        if is_metadata_line(text):
            self._current = text
            return

        # 清空旧队列
        self._events = []

        anchor = d.changed_at if d.changed_at > 0 else now_ms
        ms = d.sentence_ms or 0
        estimate = estimate_hold_ms(text)
        if ms > estimate * INTERLUDE_FACTOR:
            ms = 0  # 间奏钳制：官方时长异常时回退估算
        eff = ms if ms > 0 else estimate

        if display_units(text) > CAPACITY_UNITS:
            pages = split_lyric_pages(text)
        else:
            pages = [text]

        # 预推命中：本句第一页已提前上屏，跳过它
        start_index = 0
        if self._prepushed_text is not None and pages and pages[0] == self._prepushed_text \
                and (now_ms - self._prepushed_at) < 5000:
            start_index = 1
        self._prepushed_text = None

        # 各页展示时长与起止：deadlines[i] = 第 i 页的"起点时刻"（首屏=高亮时刻-提前量）
        total_units = max(sum(display_units(p) for p in pages), 1.0)
        acc = 0.0
        deadlines = []
        for p in pages:
            deadlines.append(anchor + acc - self.config.lead_ms)
            acc += eff * display_units(p) / total_units

        anim = self.config.animation
        layout = layout_for(anim)
        self._push_event(anchor, "layout", layout)
        for i in range(start_index, len(pages)):
            due = deadlines[i]
            end = deadlines[i + 1] if i + 1 < len(pages) else anchor + acc
            if is_device_animation(anim):
                self._push_event(due, "text", pages[i])
            else:
                self._push_event(due, "frames", (pages[i], end, anim))
                # 保证第一帧立即上屏（帧事件可能晚于该页起点的毫秒级延迟）
                if due <= time.time() * 1000.0:
                    self._push_event(due, "text", pages[i])

        # 下一句第一页预推：用音乐时钟（data-time 时间戳）精确计算，提前 lead 推送
        nx = (d.next_text or "").strip()
        if nx and nx != text and anchor > 0:
            # 歌曲起点的墙钟：当前句高亮时刻 - 当前句音乐时间戳（秒）。
            # 网易云界面高亮相对 data-time 有 ±数百 ms 漂移，用最近几句滑动平均平滑。
            if d.time_s and d.time_s > 0 and anchor > 0:
                sample = anchor - d.time_s * 1000.0
                if self._song_samples and abs(sample - self._song_start) > 2000:
                    self._song_samples.clear()   # 切歌/拖动进度：重置基准
                self._song_samples.append(sample)
                self._song_start = sum(self._song_samples) / len(self._song_samples)
            if d.next_time_s and d.next_time_s > 0 and self._song_start:
                next_due = self._song_start + d.next_time_s * 1000.0 - self.config.lead_ms
            else:
                next_due = anchor + ms - self.config.lead_ms
            if now_ms - 500 <= next_due <= now_ms + PRE_PUSH_WINDOW_MS:
                if display_units(nx) > CAPACITY_UNITS:
                    npages = split_lyric_pages(nx)
                else:
                    npages = [nx]
                if npages:
                    self._push_event(next_due, "prepush", npages[0])

        self._current = text

    # ---------- 主循环 ----------
    def run(self):
        self.log("[引擎] 启动（动画=%s）" % self.config.animation)
        self._ensure_color()
        reconnect_delay = 1.0
        while not self._stop.is_set():
            try:
                if not self.source.is_ready():
                    raise RuntimeError("CDP 未连接")
                data = self.source.poll()
                if data is not None:
                    reconnect_delay = 1.0
                    if data.text and data.text != self._current:
                        self._on_line(data)
                self._drain_events(time.time() * 1000.0)
                self.device.drain()
                self._stop.wait(POLL_INTERVAL)
            except Exception as exc:
                self._drain_events(time.time() * 1000.0)
                self.log("[重连] CDP 连接异常: %s，%.1fs 后重试" % (exc, reconnect_delay))
                try:
                    self.source.connect()
                    self.log("[重连] 已重新注入歌词监听")
                except Exception as exc2:
                    self.log("[重连失败] %s" % exc2)
                self._stop.wait(reconnect_delay)
                reconnect_delay = min(reconnect_delay * 2, 8.0)
        self.log("[引擎] 已停止")
