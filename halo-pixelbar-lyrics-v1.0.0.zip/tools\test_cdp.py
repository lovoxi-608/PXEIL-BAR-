# -*- coding: utf-8 -*-
"""CDP 歌词采集测试：连接网易云调试口、注入监听脚本、轮询当前歌词。"""
import json
import time

import requests
import websocket

PORT = 9222

WATCHER_JS = r"""
(function () {
    if (window.__haloLyric && window.__haloLyric.v === 7) { return 'alive'; }
    if (window.__haloLyricTimer) { try { clearInterval(window.__haloLyricTimer); } catch (e) { } }
    var state = { observer: null, lastTime: null };

    function update() {
        var t = null, ms = 0, nx = null;
        var li = document.querySelector('ul.lyric li.current');
        if (li) {
            var ps = Array.prototype.slice.call(li.querySelectorAll('p'))
                .map(function (p) { return (p.textContent || '').trim(); })
                .filter(Boolean);
            t = ps.length ? ps[0] : null;
            var t0 = parseFloat(li.getAttribute('data-time'));
            var sib = li.nextElementSibling;
            var t1 = sib ? parseFloat(sib.getAttribute('data-time')) : NaN;
            if (isFinite(t0) && isFinite(t1) && t1 > t0) ms = Math.round((t1 - t0) * 1000);
            if (sib) {
                var nps = Array.prototype.slice.call(sib.querySelectorAll('p'))
                    .map(function (p) { return (p.textContent || '').trim(); })
                    .filter(Boolean);
                nx = nps.length ? nps[0] : null;
            }
            if (t0 !== state.lastTime) {
                state.lastTime = t0;
                window.__haloLyric.changedAt = Date.now();
            }
        }
        window.__haloLyric.current = t;
        window.__haloLyric.sentenceMs = ms;
        window.__haloLyric.nextText = nx;
    }

    function mount() {
        if (state.observer) return true;
        var ul = document.querySelector('ul.lyric');
        if (!ul) return false;
        state.observer = new MutationObserver(function (muts) {
            for (var i = 0; i < muts.length; i++) {
                var m = muts[i];
                if (m.type === 'attributes') {
                    if (/(^|\s)current(\s|$)/.test(String(m.target.className || ''))) { update(); return; }
                } else if (m.type === 'childList') { update(); return; }
            }
        });
        state.observer.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['class'] });
        update();
        return true;
    }

    window.__haloLyric = { v: 7, current: null, sentenceMs: 0, changedAt: 0, nextText: null };
    window.__haloLyricTimer = setInterval(function () { if (!mount()) update(); }, 800);
    mount();
    update();
    return 'installed';
})()
"""

POLL_JS = ("window.__haloLyric ? JSON.stringify({t: window.__haloLyric.current === null ? '' : "
           "window.__haloLyric.current, ms: window.__haloLyric.sentenceMs || 0, "
           "at: window.__haloLyric.changedAt || 0, nx: window.__haloLyric.nextText === null ? '' : "
           "window.__haloLyric.nextText}) : null")


def find_page_ws():
    targets = requests.get("http://127.0.0.1:%d/json" % PORT, timeout=3).json()
    for t in targets:
        if t.get("type") == "page" and str(t.get("url", "")).startswith("orpheus://"):
            return t["webSocketDebuggerUrl"], t.get("url")
    return None, None


def main():
    ws_url, url = find_page_ws()
    if not ws_url:
        print("未找到 orpheus:// 页面 target")
        return
    print("页面:", url)
    ws_url = ws_url.replace("localhost", "127.0.0.1")
    ws = websocket.create_connection(ws_url, timeout=8)
    seq = [0]

    def send(method, params=None, mid=None):
        seq[0] += 1
        msg = {"id": seq[0], "method": method}
        if params:
            msg["params"] = params
        ws.send(json.dumps(msg))
        return seq[0]

    def wait_response(mid, timeout=5):
        t_end = time.time() + timeout
        while time.time() < t_end:
            raw = ws.recv()
            d = json.loads(raw)
            if d.get("id") == mid:
                return d
        return None

    send("Runtime.enable")
    mid = send("Runtime.evaluate", {"expression": WATCHER_JS, "returnByValue": True})
    r = wait_response(mid)
    if r:
        try:
            print("注入结果:", r["result"]["result"].get("value"))
        except Exception:
            print("注入响应:", json.dumps(r, ensure_ascii=False)[:300])

    print("=== 轮询 8 次（每 500ms）===")
    for i in range(8):
        mid = send("Runtime.evaluate", {"expression": POLL_JS, "returnByValue": True})
        r = wait_response(mid, timeout=3)
        val = None
        if r:
            try:
                val = r["result"]["result"].get("value")
            except Exception:
                pass
        print("poll%d: %s" % (i, val))
        time.sleep(0.5)
    ws.close()


if __name__ == "__main__":
    main()
