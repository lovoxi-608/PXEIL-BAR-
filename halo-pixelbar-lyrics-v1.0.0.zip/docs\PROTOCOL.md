# 花再 Halo PixelBar 通信协议（逆向笔记）

> 基于社区逆向成果（halo-pixelbar-mcp / HaloPixelLyric / PixelBar 等）与本机实测整理。
> 设备固件升级可能导致以下细节变化；实测机型固件接受本文所述「变体 A」帧格式。

## 设备标识

| 项 | 值 |
|---|---|
| 厂商 | 花再（漫步者 EDIFIER 子品牌） |
| 型号 | Halo PixelBar 深渊字幕音箱 |
| USB VID | `0x2D99` |
| USB PID | `0xA160` |
| 控制接口 | 接口 4（MI_04）集合 2，HID usage page `0xFF14`（65300），usage 1 |

连接方式：USB 线直连电脑（声卡输入模式）。设备上电后为时钟模式。

## 帧格式

控制请求为 64 字节 HID Output 报文：

```
2E AA ED <cmd> <len_hi> <len_lo> <payload...> <checksum> 00 ... 00
```

- 固定头：`2E AA ED`
- `cmd`：命令码（见下）
- `len`：payload 长度（大端 16 位）
- `checksum`：自 `0xAA` 起（含 `0xAA`）所有字节求和，`& 0xFF`
- 剩余字节补 `0x00` 至 64 字节

> 注：另一社区版本使用 `0xEC` 头 + 按偏移加权校验，本机 A160 固件实测**文字不生效**；
> 上述 `0xED` + 全帧求和校验（变体 A）为本机验证可用。

## 命令

### 显示文本 — `0xE8`

```
payload: [0x00, text_len, utf8_bytes...]
```

- 单页文本上限约 16 个全角字 / 50 字节
- 长句需由上层分页后逐页推送

### 查询当前文本 — `0xE7`

```
payload: [0x00]
```

响应（Input 报文 payload）形如 `00 10 32 <len> <text> 64`。

### 布局 / 动画 — `0xEF`

**01 布局**：

```
[01, R, G, B, 00, 02, scroll, mode, FF]
```

- `scroll=0`：静态，`mode`：0 左对齐 / 1 居中 / 2 右对齐 / 3 两端
- `scroll=1`：滚动，`mode`：0 从左向右 / 1 从右向左

**03 颜色**：

```
[03, R, G, B, 00, 00, FF, FF, FF]
```

> 注意：`0xEF 01` 中的 RGB 字段会被固件忽略，颜色必须用 `0xEF 03` 单独下发。

**02 场景**：

```
[02, R, G, B, 00, 01, cat, tpl, FF]
```

### 其他

| cmd | 用途 | 说明 |
|---|---|---|
| `0xEE` | 状态回读 | 固件应答设备状态 |
| `0x66` / `0x67` | 音量 | 未在本项目使用 |

## 已知限制

- 设备字库有限：个别生僻字符渲染为空白
- 颜色单独下发（`0xEF 03`），布局中的 RGB 无效
- HID `read(timeout=0)` 在 Windows 上会无限阻塞（实测），需用短超时排空响应

## 参考实现

社区逆向项目（按名称检索即可找到）：

- `halo-pixelbar-mcp` — Python HID + 协议笔记
- `HaloPixelLyric` — C#：CDP 歌词 → PixelBar
- `traceless929/PixelBar` — C# SDK
