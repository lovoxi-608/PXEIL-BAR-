# -*- coding: utf-8 -*-
"""
花再 Halo PixelBar 歌词投射 —— 主程序（Web 控制版）
把本地运行的网易云音乐歌词实时投射到漫步者花再 Halo PixelBar 像素屏，
内置多种字幕播放动画。程序启动后自动打开浏览器控制页
（http://127.0.0.1:8227），所有操作在页面上完成。
"""
from __future__ import annotations

import json
import os
import sys
import threading
import time
import webbrowser
from collections import deque
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from animations import ANIMATIONS
from halo_device import HaloDevice, HaloError, device_info
from lyric_engine import EngineConfig, LyricEngine
from netease_lyric import (NeteaseCdpSource, get_netease_title,
                           is_debug_ready, restart_cloudmusic_with_debug,
                           wait_debug_ready)

import requests

try:
    import pystray
    from PIL import Image, ImageDraw
except Exception:
    pystray = None
    Image = ImageDraw = None

APP_TITLE = "花再 Halo PixelBar 歌词投射"
COLORS = [
    ("粉色", (0xF0, 0xB4, 0xC8)),
    ("白色", (0xFF, 0xFF, 0xFF)),
    ("红色", (0xFF, 0x40, 0x40)),
    ("绿色", (0x40, 0xFF, 0x80)),
    ("蓝色", (0x40, 0xA0, 0xFF)),
    ("青色", (0x00, 0xFF, 0xFF)),
    ("黄色", (0xFF, 0xFF, 0x00)),
    ("紫色", (0xC0, 0x80, 0xFF)),
]
DEFAULT_COLOR = (0xF0, 0xB4, 0xC8)
DEFAULT_PORT = 8227
LOG_MAX = 400


def exe_dir() -> str:
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


PAGE_HTML = """<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>花再 Halo PixelBar 歌词投射</title>
<style>
:root { color-scheme: dark; }
* { box-sizing: border-box; margin: 0; padding: 0; }
body {
  font-family: "Microsoft YaHei UI", "PingFang SC", sans-serif;
  background: #12141c; color: #e8e8ec; min-height: 100vh; padding: 28px 16px;
  display: flex; justify-content: center;
}
.card {
  width: 100%; max-width: 560px; background: #1a1d29;
  border: 1px solid #2a2e42; border-radius: 16px; padding: 22px 24px;
  box-shadow: 0 12px 40px rgba(0,0,0,.45);
}
h1 { font-size: 19px; margin-bottom: 2px; letter-spacing: .5px; }
.sub { color: #8b90a8; font-size: 12px; margin-bottom: 18px; }
.row { display: flex; align-items: center; gap: 10px; margin: 9px 0; font-size: 14px; }
.lbl { width: 76px; color: #aab; flex-shrink: 0; }
.val { flex: 1; color: #6ee7a8; word-break: break-all; }
.val.blue { color: #7cc4ff; } .val.pink { color: #ff9ec4; }
.sel { flex: 1; background: #232738; color: #e8e8ec; border: 1px solid #343a55;
  border-radius: 8px; padding: 7px 10px; font-size: 14px; outline: none; }
.sel:focus { border-color: #6c5ce7; }
.slider { flex: 1; accent-color: #6c5ce7; }
.btns { display: flex; gap: 10px; margin: 18px 0 6px; }
button {
  flex: 1; border: 0; border-radius: 10px; padding: 11px 0; font-size: 15px;
  cursor: pointer; color: #fff; background: #6c5ce7; transition: filter .15s;
}
button:hover { filter: brightness(1.12); }
button:disabled { filter: grayscale(.6) brightness(.6); cursor: default; }
button.green { background: #1db954; }
button.gray { background: #3a3f55; }
button.red { background: #e5484d; }
.lyric {
  margin: 14px 0 6px; padding: 12px 14px; border-radius: 10px;
  background: #232738; color: #ff9ec4; font-size: 15px; line-height: 1.6; min-height: 48px;
}
.log {
  margin-top: 14px; background: #0e1017; border: 1px solid #23273a; border-radius: 10px;
  padding: 10px 12px; height: 190px; overflow-y: auto;
  font: 12px/1.8 Consolas, monospace; color: #9aa2c0; white-space: pre-wrap;
}
.foot { margin-top: 12px; color: #6b7088; font-size: 11px; text-align: center; }
</style>
</head>
<body>
<div class="card">
  <h1>🎵 花再 Halo PixelBar 歌词投射</h1>
  <div class="sub">网易云音乐歌词 → USB 像素屏字幕</div>

  <div class="row"><span class="lbl">音响设备</span><span class="val" id="device">未检测</span></div>
  <div class="row"><span class="lbl">网易云</span><span class="val blue" id="netease">未连接歌词通道</span></div>
  <div class="row"><span class="lbl">正在播放</span><span class="val" id="song">-</span></div>
  <div class="lyric" id="lyric">（等待歌词…）</div>

  <div class="row"><span class="lbl">网易云程序</span>
    <input type="text" class="sel" id="npath" placeholder="cloudmusic.exe 完整路径，留空自动查找" style="flex:1">
    <button class="gray" style="flex:0 0 auto; padding:7px 12px; font-size:13px" id="npathsave">保存</button></div>

  <div class="row"><span class="lbl">字幕动画</span>
    <select class="sel" id="anim"></select></div>
  <div class="row"><span class="lbl">颜色</span>
    <select class="sel" id="color"></select></div>
  <div class="row"><span class="lbl">提前量</span>
    <input type="range" class="slider" id="lead" min="300" max="700" step="10" value="450">
    <span class="val" style="width:44px;flex:0 0 44px" id="leadv">450ms</span></div>

  <div class="btns">
    <button class="green" id="start">启动投射</button>
    <button class="gray" id="stop" disabled>停止并恢复时钟</button>
    <button class="red" id="quit">退出</button>
  </div>

  <div class="log" id="log"></div>
  <div class="foot">退出程序后像素屏自动恢复时钟模式 · 本页面仅本机可访问</div>
</div>

<script>
var busy = false;
function $(id){ return document.getElementById(id); }
function animName(k){ var a = window._anims||[]; for (var i=0;i<a.length;i++) if(a[i][0]===k) return a[i][1]; return k; }
function api(path, body){
  return fetch(path, {method: body? 'POST':'GET',
    headers: {'Content-Type':'application/json'},
    body: body? JSON.stringify(body): undefined}).then(function(r){return r.json();});
}
function refresh(){
  api('/api/state').then(function(s){
    window._anims = s.anims;
    $('device').textContent = s.device;
    $('netease').textContent = s.netease;
    $('song').textContent = s.song;
    $('lyric').textContent = s.lyric;
    $('start').disabled = s.running; $('stop').disabled = !s.running;
    var a = $('anim'); if (!a._inited) {
      s.anims.forEach(function(x){ var o=document.createElement('option'); o.value=x[0]; o.textContent=x[1]; a.appendChild(o); });
      s.colors.forEach(function(c){ var o=document.createElement('option'); o.value=c; o.textContent=c; $('color').appendChild(o); });
      a.value = s.animation; $('color').value = s.color;
      a._inited = true;
    }
    $('lead').value = s.lead_ms; $('leadv').textContent = s.lead_ms + 'ms';
    $('npath').value = s.netease_path || '';
    $('log').textContent = s.logs.join('\\n');
    $('log').scrollTop = $('log').scrollHeight;
  }).catch(function(){});
}
function pushCfg(){ api('/api/config', {animation:$('anim').value, color:$('color').value, lead_ms:+$('lead').value}); }
$('anim').addEventListener('change', pushCfg);
$('color').addEventListener('change', pushCfg);
$('lead').addEventListener('change', pushCfg);
$('npathsave').addEventListener('click', function(){
  var b = $('npathsave'), v = $('npath').value.trim();
  api('/api/config', {netease_path:v}).then(function(){
    b.textContent = '已保存'; setTimeout(function(){ b.textContent = '保存'; }, 1500);
  });
});
$('start').addEventListener('click', function(){
  if (busy) return; busy = true;
  api('/api/start', {}).then(function(r){
    if (r.need_restart_confirm) {
      if (confirm(r.msg + '\\n\\n点击确定将重启网易云音乐')) {
        api('/api/start', {confirm_restart:true}).then(function(r2){
          if (!r2.ok) alert(r2.msg);
        });
      }
    } else if (!r.ok) alert(r.msg);
  }).finally(function(){ busy = false; });
});
$('stop').addEventListener('click', function(){ api('/api/stop', {}); });
$('quit').addEventListener('click', function(){ api('/api/quit', {}); });
refresh(); setInterval(refresh, 800);
</script>
</body>
</html>
"""


class App:
    """核心服务：设备 + 歌词源 + 引擎 + 状态聚合（无 GUI 依赖）"""

    def __init__(self):
        self.device = HaloDevice()
        self.source = NeteaseCdpSource(port=9222, log=self.post_log)
        self.engine = None
        self.running = False
        self.anim_key = ANIMATIONS[0][0]
        self.color_name = COLORS[0][0]
        self.lead_ms = 450
        self.netease_path = ""
        self.song_title = "-"
        self.current_lyric = "（等待歌词…）"
        self.device_state = "未检测"
        self.netease_state = "未连接歌词通道"
        self.logs = deque(maxlen=LOG_MAX)
        self.log_path = os.path.join(exe_dir(), "halolyric.log")
        self.lock = threading.Lock()
        self.server = None
        self.refresh_device()
        threading.Thread(target=self._title_loop, daemon=True).start()

    # ---------- 日志 / 状态 ----------
    def post_log(self, msg):
        line = "[%s] %s" % (time.strftime("%H:%M:%S"), msg)
        with self.lock:
            self.logs.append(line)
        try:
            with open(self.log_path, "a", encoding="utf-8") as f:
                f.write(line + "\n")
        except Exception:
            pass

    def post_lyric(self, text):
        with self.lock:
            self.current_lyric = text

    def refresh_device(self):
        info = device_info()
        if info:
            self.device_state = "已连接（%s）" % (info.get("product") or "Halo PixelBar")
        else:
            self.device_state = "未检测到（请插好 USB）"

    def _title_loop(self):
        while True:
            try:
                t = get_netease_title()
                if t:
                    with self.lock:
                        self.song_title = t
            except Exception:
                pass
            time.sleep(3)

    def _selected_color(self):
        for name, rgb in COLORS:
            if name == self.color_name:
                return rgb
        return DEFAULT_COLOR

    # ---------- 启动 / 停止 ----------
    def on_start(self, confirm_restart: bool = False) -> dict:
        if self.running:
            return {"ok": False, "msg": "已在运行中"}
        self.post_log("正在启动…")
        try:
            self.device.connect()
            self.post_log("[OK] 像素屏控制接口已连接")
            self.refresh_device()
        except HaloError as e:
            self.post_log("[错误] %s" % e)
            return {"ok": False, "msg": "%s\n\n请确认音响已通过 USB 连接电脑并开机。" % e}
        if not is_debug_ready():
            if not confirm_restart:
                return {"ok": False, "need_restart_confirm": True,
                        "msg": "歌词同步需要网易云音乐以调试模式运行。\n是否重启网易云音乐？（会自动恢复你正在播放的内容）"}
            self.post_log("正在重启网易云并开启歌词通道…")
            if not restart_cloudmusic_with_debug(custom=self.netease_path or None):
                return {"ok": False, "msg": "未找到网易云音乐程序（%s），请先在页面填写 cloudmusic.exe 路径或安装网易云。" % (self.netease_path or "自动查找")}
            if not wait_debug_ready(timeout=40):
                return {"ok": False, "msg": "网易云已重启但歌词通道未就绪，请重试。"}
            self.post_log("[OK] 网易云歌词通道已就绪")
        try:
            self.source.connect()
            self.netease_state = "歌词通道已连接"
        except Exception as e:
            self.netease_state = "歌词通道连接失败"
            return {"ok": False, "msg": "连接网易云歌词通道失败：%s\n\n请先打开一次播放页（点击底部播放条的歌曲进入黑胶页）。" % e}
        cfg = EngineConfig(animation=self.anim_key, color=self._selected_color(),
                           lead_ms=self.lead_ms)
        self.engine = LyricEngine(self.device, self.source, cfg,
                                  log=self.post_log, on_lyric=self.post_lyric)
        self.engine.start()
        self.running = True
        self.post_log("投射已启动，开始同步歌词…")
        return {"ok": True}

    def on_stop(self) -> dict:
        if not self.running:
            return {"ok": True}
        self.post_log("正在停止…")
        self.running = False
        if self.engine:
            self.engine.stop()
            self.engine.join(timeout=3)
            self.engine = None
        try:
            self.device.restore_clock()
            self.post_log("[OK] 已停止，像素屏恢复时钟模式")
        except Exception as e:
            self.post_log("[警告] 恢复时钟失败: %s" % e)
        self.netease_state = "已停止"
        return {"ok": True}

    def on_close(self):
        try:
            self.on_stop()
        except Exception:
            pass
        try:
            self.device.close()
        except Exception:
            pass

    def apply_config(self, animation=None, color=None, lead_ms=None, netease_path=None) -> dict:
        with self.lock:
            if animation in [k for k, _ in ANIMATIONS]:
                self.anim_key = animation
            if color in [c[0] for c in COLORS]:
                self.color_name = color
            if isinstance(lead_ms, (int, float)) and 300 <= lead_ms <= 700:
                self.lead_ms = int(lead_ms)
            if isinstance(netease_path, str):
                self.netease_path = netease_path.strip().strip('"').strip()
                self.post_log("网易云程序路径：%s" % (self.netease_path or "（自动查找）"))
        if self.engine:
            self.engine.config.animation = self.anim_key
            self.engine.config.color = self._selected_color()
            self.engine.config.lead_ms = self.lead_ms
            self.post_log("参数已更新：动画=%s 颜色=%s 提前量=%dms"
                          % (self.anim_key, self.color_name, self.lead_ms))
        return {"ok": True}

    def state_dict(self) -> dict:
        with self.lock:
            return {
                "running": self.running,
                "device": self.device_state,
                "netease": self.netease_state,
                "song": self.song_title,
                "lyric": self.current_lyric,
                "animation": self.anim_key,
                "color": self.color_name,
                "lead_ms": self.lead_ms,
                "netease_path": self.netease_path,
                "anims": [[k, n] for k, n in ANIMATIONS],
                "colors": [c[0] for c in COLORS],
                "logs": list(self.logs)[-60:],
            }


class Handler(BaseHTTPRequestHandler):
    app: App = None

    def log_message(self, *a):
        pass

    def _send(self, code, obj, ctype="application/json; charset=utf-8"):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8") if not isinstance(obj, bytes) else obj
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _body(self):
        try:
            n = int(self.headers.get("Content-Length") or 0)
            if n <= 0:
                return {}
            return json.loads(self.rfile.read(n).decode("utf-8"))
        except Exception:
            return {}

    def do_GET(self):
        app = self.app
        if self.path == "/" or self.path.startswith("/index"):
            self._send(200, PAGE_HTML.encode("utf-8"), "text/html; charset=utf-8")
        elif self.path == "/api/state":
            self._send(200, app.state_dict())
        else:
            self._send(404, {"ok": False, "msg": "not found"})

    def do_POST(self):
        app = self.app
        body = self._body()
        if self.path == "/api/start":
            self._send(200, app.on_start(bool(body.get("confirm_restart"))))
        elif self.path == "/api/stop":
            self._send(200, app.on_stop())
        elif self.path == "/api/config":
            self._send(200, app.apply_config(body.get("animation"),
                                             body.get("color"),
                                             body.get("lead_ms"),
                                             body.get("netease_path")))
        elif self.path == "/api/quit":
            threading.Thread(target=app.on_close, daemon=True).start()
            self._send(200, {"ok": True})
            threading.Thread(target=self.server.shutdown, daemon=True).start()
            tray = getattr(app, "tray", None)
            if tray:
                threading.Thread(target=tray.stop, daemon=True).start()
        else:
            self._send(404, {"ok": False, "msg": "not found"})


def find_existing_instance(start_port: int = DEFAULT_PORT) -> int | None:
    """探测是否已有实例在运行（控制页已占用），返回其端口；无则 None。"""
    for port in range(start_port, start_port + 10):
        try:
            r = requests.get("http://127.0.0.1:%d/api/state" % port, timeout=0.8)
            if r.status_code == 200:
                return port
        except Exception:
            continue
    return None


def make_server(app: App, start_port: int = DEFAULT_PORT) -> ThreadingHTTPServer:
    for port in range(start_port, start_port + 10):
        try:
            Handler.app = app
            srv = ThreadingHTTPServer(("127.0.0.1", port), Handler)
            return srv
        except OSError:
            continue
    raise RuntimeError("无法绑定本地控制端口（%d-%d）" % (start_port, start_port + 9))


def make_icon_image():
    """生成一个像素屏风格的托盘图标（RGBA 64x64）"""
    if Image is None or ImageDraw is None:
        return None
    try:
        img = Image.new("RGBA", (64, 64), (18, 20, 28, 255))
        d = ImageDraw.Draw(img)
        d.rectangle([6, 12, 58, 20], fill=(108, 92, 231, 255))        # 顶部状态条
        d.rounded_rectangle([10, 28, 54, 33], radius=2, fill=(124, 196, 255, 255))  # 装饰
        d.rounded_rectangle([6, 40, 58, 56], radius=4, fill=(240, 180, 200, 255))   # 字幕条
        return img
    except Exception:
        return None


def build_tray(app: App, server, url: str):
    """创建系统托盘图标：显示运行状态，右键菜单 打开控制页 / 退出。"""
    if pystray is None:
        app.post_log("[提示] 未安装 pystray，系统托盘不可用（不影响使用）")
        return None
    try:
        def on_open(icon, item):
            webbrowser.open(url)

        def on_exit(icon, item):
            icon.stop()
            threading.Thread(target=server.shutdown, daemon=True).start()

        icon = pystray.Icon(APP_TITLE, make_icon_image(), APP_TITLE, menu=pystray.Menu(
            pystray.MenuItem("打开控制页", on_open, default=True),
            pystray.MenuItem("退出", on_exit)))
        return icon
    except Exception as e:
        app.post_log("[提示] 系统托盘初始化失败: %s" % e)
        return None


def main():
    # 已运行：直接打开已运行实例的控制页，新实例立即退出（秒开，不等重启）
    exist = find_existing_instance()
    if exist:
        webbrowser.open("http://127.0.0.1:%d/" % exist)
        return
    app = App()
    try:
        server = make_server(app)
    except RuntimeError as e:
        app.post_log("[错误] %s" % e)
        return
    app.server = server
    url = "http://127.0.0.1:%d/" % server.server_address[1]
    app.post_log("控制页已就绪：%s （浏览器未自动打开请手动访问）" % url)
    threading.Thread(target=lambda: (time.sleep(0.6), webbrowser.open(url)),
                     daemon=True).start()
    tray = build_tray(app, server, url)
    app.tray = tray
    srv = threading.Thread(target=server.serve_forever, daemon=True)
    srv.start()
    if tray:
        tray.run()          # 主线程：托盘消息循环（右下角图标）
    else:
        while srv.is_alive():
            time.sleep(0.5)
    # 退出路径：托盘「退出」或控制页「退出」（/api/quit）
    if srv.is_alive():
        try:
            server.shutdown()
        except Exception:
            pass
    srv.join(timeout=3)
    app.on_close()


if __name__ == "__main__":
    main()
