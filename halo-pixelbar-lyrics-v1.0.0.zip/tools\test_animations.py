# -*- coding: utf-8 -*-
"""单元测试：分页 + 软件动画帧生成 + 设备动画实测（打字机 8 秒）"""
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from animations import gen_frames
from lyric_engine import estimate_hold_ms, split_lyric_pages

# --- 1. 分页 ---
long_line = "Dance through the dark Spotlight Hunter I can't take a seat"
pages = split_lyric_pages(long_line)
print("分页:", pages)
assert all(len(p) > 0 for p in pages)

cn_long = "这是一段超过屏幕宽度需要分页显示的歌词内容测试"
cn_pages = split_lyric_pages(cn_long)
print("中文分页:", cn_pages)
assert len(cn_pages) >= 2

# --- 2. 动画帧 ---
for anim in ("typewriter", "blink", "bounce", "pop"):
    frames = gen_frames("测试歌词文字", 2000, anim)
    print("%s: %d 帧, 示例 %r" % (anim, len(frames), frames[:3]))
    assert frames

# --- 3. 设备实测定时: 打字机 8 秒 ---
from halo_device import HaloDevice
from lyric_engine import EngineConfig, LyricEngine
from netease_lyric import NeteaseCdpSource

print("\n== 打字机动画实测 ==")
dev = HaloDevice()
dev.connect()
src = NeteaseCdpSource(log=lambda m: None)
src.connect()
pushed = []
eng = LyricEngine(dev, src, EngineConfig(animation="typewriter", color=(255, 255, 255), lead_ms=200),
                  log=lambda m: None, on_lyric=lambda t: pushed.append(t))
eng.start()
time.sleep(8)
eng.stop()
eng.join(3)
print("打字机推送次数: %d" % len(pushed))
print("最近 5 次: %r" % pushed[-5:])
time.sleep(0.3)
print("屏幕当前文本: %r" % dev.query_text())
dev.restore_clock()
dev.close()
print("完成")
