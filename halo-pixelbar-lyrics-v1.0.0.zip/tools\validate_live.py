# -*- coding: utf-8 -*-
"""实机对照：网易云当前歌词行 vs 音箱屏幕实际显示，20 秒逐秒采样"""
import json
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import requests
import websocket

from halo_device import HaloDevice

POLL_JS = ("window.__haloLyric ? JSON.stringify({t: window.__haloLyric.current === null ? '' : "
           "window.__haloLyric.current}) : null")


def main():
    # 网易云侧
    targets = requests.get("http://127.0.0.1:9222/json", timeout=2).json()
    ws_url = None
    for t in targets:
        if t.get("type") == "page" and str(t.get("url", "")).startswith("orpheus://"):
            ws_url = t.get("webSocketDebuggerUrl")
            break
    ws = websocket.create_connection(ws_url.replace("localhost", "127.0.0.1"), timeout=8)

    def netease_line():
        ws.send(json.dumps({"id": 1, "method": "Runtime.evaluate",
                            "params": {"expression": POLL_JS, "returnByValue": True}}))
        end = time.time() + 3
        while time.time() < end:
            d = json.loads(ws.recv())
            if d.get("id") == 1:
                try:
                    v = d["result"]["result"].get("value")
                    return json.loads(v).get("t", "") if v else ""
                except Exception:
                    return ""
        return ""

    dev = HaloDevice()
    dev.connect()

    print("=== 网易云当前行 vs 音箱屏幕（20 秒逐秒采样）===")
    for i in range(20):
        nl = netease_line()
        screen = dev.query_text() or ""
        same = "一致" if screen == nl else ("分页/换句" if nl.startswith(screen) or screen.startswith(nl) or len(screen) < 16 else "不一致")
        print("%2d 网易云:%-24s | 音箱:%-20s | %s" % (i, nl[:24], screen[:20], same))
        time.sleep(1)
    dev.restore_clock()
    dev.close()
    ws.close()


if __name__ == "__main__":
    main()
