# -*- coding: utf-8 -*-
"""端到端集成测试：设备 + CDP + 引擎，运行 12 秒后恢复时钟。"""
import os
import sys
import time
import faulthandler

faulthandler.dump_traceback_later(25, exit=True)

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from halo_device import HaloDevice
from lyric_engine import EngineConfig, LyricEngine
from netease_lyric import NeteaseCdpSource, is_debug_ready

if not is_debug_ready():
    print("CDP 调试口未就绪")
    sys.exit(1)

print("== 连接设备 ==")
device = HaloDevice()
device.connect()
print("设备已连接")

print("== 连接网易云 CDP ==")
source = NeteaseCdpSource(log=lambda m: print("  ", m))
source.connect()

pushed = []


def on_lyric(t):
    pushed.append(t)
    print("  [推屏] %r" % t)


cfg = EngineConfig(animation="scroll_r2l", color=(255, 255, 255), lead_ms=280)
engine = LyricEngine(device, source, cfg, log=lambda m: print("  ", m), on_lyric=on_lyric)
engine.start()
print("== 引擎运行 12 秒 ==")
time.sleep(6)
print("== 运行中设备屏幕文本: %r ==" % device.query_text())
time.sleep(6)
engine.stop()
engine.join(3)
print("== 推送统计: 共 %d 次，最近: %r" % (len(pushed), pushed[-4:]))
time.sleep(0.5)
print("== 停止后（恢复时钟前）设备屏幕文本: %r" % device.query_text())
device.restore_clock()
device.close()
print("== 完成，已恢复时钟 ==")
