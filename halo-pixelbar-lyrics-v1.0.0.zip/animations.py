# -*- coding: utf-8 -*-
"""字幕播放动画：设备端布局动画 + 软件端逐帧动画。"""

# (key, 显示名)
ANIMATIONS = [
    ("center",     "静态居中"),
    ("left",       "静态左对齐"),
    ("right",      "静态右对齐"),
    ("scroll_r2l", "横向滚动（右→左）"),
    ("scroll_l2r", "横向滚动（左→右）"),
    ("typewriter", "打字机"),
    ("blink",      "闪烁"),
    ("bounce",     "左右弹跳"),
]

# 设备原生布局动画（一次性下发，固件自己动）
DEVICE_LAYOUTS = {"center", "left", "right", "scroll_r2l", "scroll_l2r"}

# 软件动画（逐帧推送文本实现）
SOFTWARE_ANIMS = {"typewriter", "blink", "bounce"}

# 弹跳动画可用的最大字符数（需要留出左右移动的空间）
BOUNCE_MAX_UNITS = 13


def is_device_animation(key: str) -> bool:
    return key in DEVICE_LAYOUTS


def layout_for(key: str) -> str:
    """软件动画统一使用静态居中承载"""
    if key in DEVICE_LAYOUTS:
        return key
    return "center"


def gen_frames(text: str, duration_ms: int, anim: str):
    """软件动画生成 (offset_ms, text) 帧序列（offset 相对该页起始时刻）"""
    duration_ms = max(200, duration_ms)
    n = max(len(text), 1)
    if anim == "typewriter":
        step = min(160, max(70, duration_ms // n))
        return [(k * step, text[:k]) for k in range(1, len(text) + 1)]
    if anim == "pop":
        step = min(150, max(60, duration_ms // n))
        frames = [(k * step, text[:k]) for k in range(1, len(text) + 1)]
        frames.append((len(text) * step, text))
        return frames
    if anim == "blink":
        period = 600
        frames = []
        t = 0
        while t < duration_ms:
            frames.append((t, text))
            t += period
            if t < duration_ms:
                frames.append((t, " " * len(text)))
            t += period
        return frames
    if anim == "bounce":
        max_shift = 3
        frames = []
        t = 0
        while t < duration_ms:
            for s in range(max_shift + 1):
                frames.append((t, " " * s + text))
                t += 65
            for s in range(max_shift - 1, 0, -1):
                frames.append((t, " " * s + text))
                t += 65
        return frames
    return []
