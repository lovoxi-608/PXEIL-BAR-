# -*- coding: utf-8 -*-
"""
网易云音乐歌词采集（CDP 方案）
原理：网易云 PC 版为 CEF/Chromium 内核；带 --remote-debugging-port 启动后，
通过 Chrome DevTools Protocol 向主页面注入监听脚本（MutationObserver 监听
ul.lyric li.current 的 class 轮转），轮询当前歌词行文本、句长与切换时刻。
数据层驱动，与播放页是否可见无关，网易云升级免疫（选择器不变时无需改动）。
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import time
import ctypes
from ctypes import wintypes

import requests
import websocket

DEFAULT_PORT = 9222

WATCHER_JS = r"""
(function () {
    if (window.__haloLyric && window.__haloLyric.v === 8) { return 'alive'; }
    if (window.__haloLyricTimer) { try { clearInterval(window.__haloLyricTimer); } catch (e) { } }
    var state = { observer: null, lastTime: null };
    function update() {
        var t = null, ms = 0, nx = null, t0 = NaN, t1 = NaN;
        var li = document.querySelector('ul.lyric li.current');
        if (li) {
            var ps = Array.prototype.slice.call(li.querySelectorAll('p'))
                .map(function (p) { return (p.textContent || '').trim(); })
                .filter(Boolean);
            t = ps.length ? ps[0] : null;
            t0 = parseFloat(li.getAttribute('data-time'));
            var sib = li.nextElementSibling;
            if (sib) {
                t1 = parseFloat(sib.getAttribute('data-time'));
                var nps = Array.prototype.slice.call(sib.querySelectorAll('p'))
                    .map(function (p) { return (p.textContent || '').trim(); })
                    .filter(Boolean);
                nx = nps.length ? nps[0] : null;
            }
            if (isFinite(t0) && isFinite(t1) && t1 > t0) ms = Math.round((t1 - t0) * 1000);
            if (t0 !== state.lastTime) {
                state.lastTime = t0;
                window.__haloLyric.changedAt = Date.now();
            }
        }
        window.__haloLyric.current = t;
        window.__haloLyric.sentenceMs = ms;
        window.__haloLyric.nextText = nx;
        window.__haloLyric.time = isFinite(t0) ? t0 : null;
        window.__haloLyric.nextTime = isFinite(t1) ? t1 : null;
    }
    function mount() {
        if (state.observer) return true;
        var ul = document.querySelector('ul.lyric');
        if (!ul) return false;
        state.observer = new MutationObserver(function (muts) {
            for (var i = 0; i < muts.length; i++) {
                var m = muts[i];
                if (m.type === 'attributes') {
                    if (/(^|\s)current(\s|$)/.test(String(m.target.className || ''))) { update(); return; }
                } else if (m.type === 'childList') { update(); return; }
            }
        });
        state.observer.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['class'] });
        update();
        return true;
    }
    window.__haloLyric = { v: 8, current: null, sentenceMs: 0, changedAt: 0, nextText: null, time: null, nextTime: null };
    window.__haloLyricTimer = setInterval(function () { if (!mount()) update(); }, 800);
    mount();
    update();
    return 'installed';
})()
"""

POLL_JS = ("window.__haloLyric ? JSON.stringify({t: window.__haloLyric.current === null ? '' : "
           "window.__haloLyric.current, ms: window.__haloLyric.sentenceMs || 0, "
           "at: window.__haloLyric.changedAt || 0, nx: window.__haloLyric.nextText === null ? '' : "
           "window.__haloLyric.nextText, tm: window.__haloLyric.time === null ? 0 : "
           "window.__haloLyric.time, ntm: window.__haloLyric.nextTime === null ? 0 : "
           "window.__haloLyric.nextTime}) : null")


class LyricData:
    __slots__ = ("text", "sentence_ms", "changed_at", "next_text", "time_s", "next_time_s")

    def __init__(self, text="", sentence_ms=0, changed_at=0, next_text="",
                 time_s=0.0, next_time_s=0.0):
        self.text = text
        self.sentence_ms = sentence_ms
        self.changed_at = changed_at
        self.next_text = next_text
        self.time_s = time_s
        self.next_time_s = next_time_s

    @staticmethod
    def parse(raw: str | None) -> "LyricData | None":
        if not raw:
            return None
        try:
            d = json.loads(raw)
            return LyricData(d.get("t", ""), d.get("ms", 0), d.get("at", 0), d.get("nx", ""),
                             float(d.get("tm", 0) or 0), float(d.get("ntm", 0) or 0))
        except Exception:
            return None


# ---------------- 进程/端口管理 ----------------

def is_debug_ready(port: int = DEFAULT_PORT) -> bool:
    try:
        r = requests.get("http://127.0.0.1:%d/json/version" % port, timeout=1.5)
        return r.status_code == 200
    except Exception:
        return False


def find_cloudmusic_path(custom: str | None = None) -> str | None:
    """从运行进程或常见路径找 cloudmusic.exe；custom 为用户在控制页填写的路径（优先）。"""
    if custom:
        custom = custom.strip().strip('"').strip()
        if custom and os.path.isfile(custom):
            return custom
    try:
        ps = subprocess.run(
            ["powershell", "-NoProfile", "-Command",
             "(Get-Process cloudmusic -ErrorAction SilentlyContinue | Where-Object {$_.Path} | Select-Object -First 1 -ExpandProperty Path)"],
            capture_output=True, text=True, timeout=8, creationflags=subprocess.CREATE_NO_WINDOW)
        p = (ps.stdout or "").strip()
        if p and os.path.isfile(p):
            return p
    except Exception:
        pass
    for cand in [
        r"C:\Program Files\Netease\CloudMusic\cloudmusic.exe",
        r"C:\Program Files (x86)\Netease\CloudMusic\cloudmusic.exe",
        r"D:\Netease\CloudMusic\cloudmusic.exe",
        r"D:\CloudMusic\cloudmusic.exe",
        r"E:\CloudMusic\cloudmusic.exe",
        # 若安装在其他路径，可自行添加，例如：
        # r"D:\网易云\CloudMusic\cloudmusic.exe",
    ]:
        if os.path.isfile(cand):
            return cand
    return None


def restart_cloudmusic_with_debug(port: int = DEFAULT_PORT,
                                  custom: str | None = None) -> bool:
    """杀掉现有网易云并以调试参数重启；返回是否成功。custom 为自定义程序路径。"""
    path = find_cloudmusic_path(custom)
    if not path:
        return False
    try:
        subprocess.run(["taskkill", "/f", "/im", "cloudmusic.exe"],
                       capture_output=True, timeout=10, creationflags=subprocess.CREATE_NO_WINDOW)
        subprocess.run(["taskkill", "/f", "/im", "cloudmusic_reporter.exe"],
                       capture_output=True, timeout=10, creationflags=subprocess.CREATE_NO_WINDOW)
    except Exception:
        pass
    time.sleep(1.5)
    try:
        subprocess.Popen(
            [path, "--remote-debugging-port=%d" % port],
            creationflags=subprocess.CREATE_NO_WINDOW | subprocess.DETACHED_PROCESS)
        return True
    except Exception:
        return False


def wait_debug_ready(port: int = DEFAULT_PORT, timeout: float = 30.0) -> bool:
    t0 = time.time()
    while time.time() - t0 < timeout:
        if is_debug_ready(port):
            return True
        time.sleep(1)
    return False


# ---------------- CDP 客户端 ----------------

class NeteaseCdpSource:
    """连接网易云 CDP 页面，注入监听并轮询歌词。断线自动重连。"""

    def __init__(self, port: int = DEFAULT_PORT, log=None):
        self.port = port
        self.log = log or (lambda msg: None)
        self._ws = None
        self._next_id = 0

    def _log(self, msg):
        try:
            self.log(msg)
        except Exception:
            pass

    def is_ready(self) -> bool:
        return self._ws is not None

    def connect(self) -> bool:
        """建立 CDP 连接并注入监听。失败抛异常。"""
        self.close()
        ws_url, page_url = self._find_page()
        if not ws_url:
            raise RuntimeError("未发现网易云 CDP 页面（orpheus://）")
        self._ws = websocket.create_connection(ws_url.replace("localhost", "127.0.0.1"), timeout=8)
        self._send("Runtime.enable")
        # 等待 enable 响应
        self._recv_until_id(self._next_id, timeout=5)
        mid = self._send("Runtime.evaluate", {"expression": WATCHER_JS, "returnByValue": True})
        r = self._recv_until_id(mid, timeout=5)
        result = None
        if r and "result" in r:
            try:
                result = r["result"].get("result", {}).get("value")
            except Exception:
                pass
        self._log("CDP 已连接，歌词监听注入: %s" % result)
        return True

    def _find_page(self):
        try:
            targets = requests.get("http://127.0.0.1:%d/json" % self.port, timeout=2).json()
        except Exception:
            return None, None
        for t in targets:
            if t.get("type") == "page" and str(t.get("url", "")).startswith("orpheus://"):
                return t.get("webSocketDebuggerUrl"), t.get("url")
        return None, None

    def _send(self, method, params=None):
        self._next_id += 1
        msg = {"id": self._next_id, "method": method}
        if params:
            msg["params"] = params
        self._ws.send(json.dumps(msg))
        return self._next_id

    def _recv_until_id(self, mid, timeout=3):
        self._ws.settimeout(timeout)
        t0 = time.time()
        while time.time() - t0 < timeout:
            try:
                raw = self._ws.recv()
            except websocket.WebSocketTimeoutException:
                return None
            except Exception:
                return None
            try:
                d = json.loads(raw)
            except Exception:
                continue
            if d.get("id") == mid:
                return d
        return None

    def poll(self) -> LyricData | None:
        """轮询一次当前歌词。连接异常抛 WebSocketException。"""
        if self._ws is None:
            raise RuntimeError("not connected")
        mid = self._send("Runtime.evaluate", {"expression": POLL_JS, "returnByValue": True})
        self._ws.settimeout(3)
        t0 = time.time()
        while time.time() - t0 < 3:
            raw = self._ws.recv()
            d = json.loads(raw)
            if d.get("id") == mid:
                try:
                    val = d["result"]["result"].get("value")
                except Exception:
                    val = None
                return LyricData.parse(val)
        return None

    def close(self):
        if self._ws is not None:
            try:
                self._ws.close()
            except Exception:
                pass
            self._ws = None


# ---------------- 窗口标题兜底 ----------------

def get_netease_title() -> str:
    """返回网易云主窗口标题（形如“歌名 - 歌手”），失败返回空。"""
    user32 = ctypes.WinDLL("user32", use_last_error=True)
    pids = set()
    try:
        out = subprocess.run(
            ["tasklist", "/fi", "imagename eq cloudmusic.exe", "/fo", "csv", "/nh"],
            capture_output=True, text=True, timeout=5,
            creationflags=subprocess.CREATE_NO_WINDOW).stdout
        for line in out.splitlines():
            parts = line.split('","')
            if len(parts) > 1 and parts[0].strip('"').lower() == "cloudmusic.exe":
                try:
                    pids.add(int(parts[1].strip('"')))
                except ValueError:
                    pass
    except Exception:
        pass
    if not pids:
        return ""

    buf = ctypes.create_unicode_buffer(512)
    found = []

    EnumWindowsProc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    @EnumWindowsProc
    def enum_proc(hwnd, lparam):
        pid = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        if pid.value in pids and user32.IsWindowVisible(hwnd):
            n = user32.GetWindowTextW(hwnd, buf, 512)
            if n > 0:
                found.append(buf.value)
        return True

    try:
        user32.EnumWindows(enum_proc, 0)
    except Exception:
        return ""
    for t in found:
        t = t.strip()
        if t and t != "桌面歌词":
            return t
    return ""


def parse_title(title: str) -> str:
    """从“歌名 - 歌手”解析歌名"""
    if not title:
        return ""
    title = title.replace(" - 网易云音乐", "").strip()
    return title
