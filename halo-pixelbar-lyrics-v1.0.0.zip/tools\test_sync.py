# -*- coding: utf-8 -*-
"""同步对照测试：网易云高亮切换时刻 vs 引擎推送时刻，量化同步差（应≈-lead，即提前 lead 推送）"""
import json
import os
import sys
import threading
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import requests
import websocket

from halo_device import HaloDevice
from lyric_engine import EngineConfig, LyricEngine
from netease_lyric import NeteaseCdpSource

PORT = 9222
DURATION = 32

POLL_JS = ("window.__haloLyric ? JSON.stringify({t: window.__haloLyric.current === null ? '' : "
           "window.__haloLyric.current, at: window.__haloLyric.changedAt || 0}) : null")


class NeteaseMonitor:
    """独立 CDP 连接，记录网易云侧高亮切换时刻（50ms 轮询）"""

    def __init__(self):
        self.lock = threading.Lock()
        self.switches = []  # (wall_ms, text)
        self.latest = (0, "")
        self._stop = threading.Event()

    def connect(self):
        targets = requests.get("http://127.0.0.1:%d/json" % PORT, timeout=2).json()
        for t in targets:
            if t.get("type") == "page" and str(t.get("url", "")).startswith("orpheus://"):
                self._ws = websocket.create_connection(
                    t["webSocketDebuggerUrl"].replace("localhost", "127.0.0.1"), timeout=8)
                return True
        return False

    def run(self):
        self._mid = 0
        last_key = None
        while not self._stop.is_set():
            self._mid += 1
            mid = self._mid
            try:
                self._ws.send(json.dumps({"id": mid, "method": "Runtime.evaluate",
                                          "params": {"expression": POLL_JS, "returnByValue": True}}))
                self._ws.settimeout(2)
                t_end = time.time() + 2
                while time.time() < t_end:
                    d = json.loads(self._ws.recv())
                    if d.get("id") == mid:
                        v = d["result"]["result"].get("value")
                        if v:
                            dd = json.loads(v)
                            text = dd.get("t") or ""
                            at = dd.get("at") or 0
                            key = text + "|" + str(at)
                            if key != last_key and at > 0:
                                last_key = key
                                with self.lock:
                                    self.switches.append((time.time() * 1000.0, text))
                                    self.latest = (at, text)
                        break
            except Exception:
                try:
                    self._ws = websocket.create_connection(
                        self._ws.url, timeout=8)
                except Exception:
                    pass
            self._stop.wait(0.05)

    def stop(self):
        self._stop.set()


def main():
    dev = HaloDevice()
    dev.connect()
    src = NeteaseCdpSource(port=PORT, log=lambda m: None)
    src.connect()

    pushed = []  # (wall_ms, text)
    eng = LyricEngine(dev, src, EngineConfig(animation="center", color=(255, 255, 255), lead_ms=200),
                      log=lambda m: None, on_lyric=lambda t: pushed.append((time.time() * 1000.0, t)))

    mon = NeteaseMonitor()
    if not mon.connect():
        print("无法建立对照监听")
        return
    mth = threading.Thread(target=mon.run, daemon=True)
    mth.start()

    eng.start()
    print("对照采样 %d 秒（lead=200ms）…" % DURATION)
    time.sleep(DURATION)
    eng.stop()
    eng.join(3)
    mon.stop()
    time.sleep(0.3)
    print("屏幕回读: %r" % dev.query_text())
    dev.restore_clock()
    dev.close()

    with mon.lock:
        switches = list(mon.switches)
    print("\n=== 网易云侧高亮切换（%d 次） vs 引擎推送（%d 次）===" % (len(switches), len(pushed)))
    print("delta = 推送时刻 - 网易云高亮时刻（负=提前推送，期望≈-200）")
    used = set()
    for wall_nm, txt_nm in switches:
        best = None
        for i, (wall_p, txt_p) in enumerate(pushed):
            if i in used:
                continue
            if txt_p == txt_nm:
                best = (i, wall_p)
                break
        if best:
            used.add(best[0])
            delta = best[1] - wall_nm
            print("delta=%+7.0fms  网易云@%.0f  推送@%.0f  %s"
                  % (delta, wall_nm, best[1], txt_nm[:24]))
        else:
            print("delta=   -   （未匹配）  %s" % txt_nm[:24])


if __name__ == "__main__":
    main()
