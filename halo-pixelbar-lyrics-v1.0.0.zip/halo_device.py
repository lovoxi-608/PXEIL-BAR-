# -*- coding: utf-8 -*-
"""
花再 Halo PixelBar HID 通信层
协议经本机（VID 0x2D99 PID 0xA160）实测验证：
  - 控制接口: HID 接口4 Col02, usage page 0xFF14, usage 1
  - 请求帧:   2E AA ED <cmd> <len_hi> <len_lo> <payload...> <checksum>  补0至64字节
  - 校验和:   自 0xAA 起所有字节求和 mod 256
  - 文本上限: 16 个全角字 / 50 字节（设备自报，超出会被固件截断）
"""
from __future__ import annotations

import threading
import time

import hid

VID = 0x2D99
PACKET_LEN = 64
MAX_TEXT_BYTES = 50  # 实测设备自报上限
MAX_TEXT_UNITS = 16  # 实测设备自报上限（全角=1单位，半角=0.5）

CMD_TEXT_SET = 0xE8
CMD_TEXT_QUERY = 0xE7
CMD_UI = 0xEF

# 布局: (滚动?, 模式) —— 01 <RGB> 00 02 <scroll> <mode> FF
LAYOUTS = {
    "left":        (0, 0),
    "center":      (0, 1),
    "right":       (0, 2),
    "stretch":     (0, 3),
    "scroll_l2r":  (1, 0),
    "scroll_r2l":  (1, 1),
}

# 场景: 02 <RGB> 00 01 <category> <template> FF
SCENES = {
    "clock": 0, "game": 1, "work": 2, "read": 3,
    "cats": 4, "dogs": 5, "memes": 6, "cyber": 7, "waves": 8,
}

DEFAULT_TEXT_COLOR = (0xF0, 0xB4, 0xC8)  # 设备出厂默认粉


class HaloError(RuntimeError):
    pass


def _pad(data: bytes) -> bytes:
    if len(data) > PACKET_LEN:
        raise HaloError("packet too large: %d bytes" % len(data))
    return data + bytes(PACKET_LEN - len(data))


def build_packet(cmd: int, payload: bytes) -> bytes:
    body = bytes(payload)
    pkt = bytearray([0x2E, 0xAA, 0xED, cmd, (len(body) >> 8) & 0xFF, len(body) & 0xFF])
    pkt.extend(body)
    pkt.append(sum(pkt[1:]) & 0xFF)
    return _pad(pkt)


def find_device_path():
    """定位 PixelBar 控制接口（usage page 0xFF14, usage 1）"""
    for d in hid.enumerate(VID, 0):
        if d.get("usage_page") == 0xFF14 and d.get("usage") == 1:
            return d.get("path")
    return None


def device_info():
    for d in hid.enumerate(VID, 0):
        if d.get("usage_page") == 0xFF14 and d.get("usage") == 1:
            return {
                "product": d.get("product_string"),
                "manufacturer": d.get("manufacturer_string"),
                "path": d.get("path"),
            }
    return None


def display_units(text: str) -> float:
    return sum(1.0 if ord(c) >= 0x2E80 else 0.5 for c in text)


def cap_text(text: str, max_units: int = MAX_TEXT_UNITS, max_bytes: int = MAX_TEXT_BYTES) -> str:
    """按 字数+字节 双重上限截断（保持字符完整）"""
    if not text:
        return ""
    text = text.strip()
    while text and (display_units(text) > max_units or len(text.encode("utf-8")) > max_bytes):
        text = text[:-1]
    return text


class HaloDevice:
    """单例式 HID 设备句柄，带线程锁；写失败自动重连"""

    def __init__(self):
        self._dev = None
        self._path = None
        self._lock = threading.Lock()

    def connect(self):
        with self._lock:
            self._open()
        return True

    def _open(self):
        path = find_device_path()
        if not path:
            raise HaloError("未找到「花再 Halo PixelBar」控制接口，请确认 USB 已连接")
        if self._dev is not None:
            try:
                self._dev.close()
            except Exception:
                pass
        dev = hid.device()
        dev.open_path(path)
        self._dev = dev
        self._path = path

    def _write(self, data: bytes):
        if self._dev is None:
            self._open()
        try:
            n = int(self._dev.write(data))
            if n < 0:
                raise HaloError("HID write error")
        except Exception:
            self._close()
            self._open()
            n = int(self._dev.write(data))
            if n < 0:
                raise HaloError("HID write error after reconnect")

    def _close(self):
        if self._dev is not None:
            try:
                self._dev.close()
            except Exception:
                pass
            self._dev = None

    def drain(self, max_reports: int = 32):
        """排空设备输入缓冲（每次写入都会产生响应报文，必须及时消费，否则缓冲溢出会阻塞写入）"""
        with self._lock:
            if self._dev is None:
                return
            try:
                for _ in range(max_reports):
                    r = self._dev.read(PACKET_LEN, 2)
                    if not r:
                        break
            except Exception:
                pass

    def send(self, cmd: int, payload: bytes):
        with self._lock:
            self._write(build_packet(cmd, payload))
            # 写入后立即排空本次响应，避免缓冲堆积
            try:
                for _ in range(4):
                    r = self._dev.read(PACKET_LEN, 2)
                    if not r:
                        break
            except Exception:
                pass

    # ---------- 高层操作 ----------

    def set_text(self, text: str):
        text = cap_text(text)
        if not text:
            return
        tb = text.encode("utf-8")
        self.send(CMD_TEXT_SET, bytes([0x00, len(tb)]) + tb)

    def set_layout(self, layout: str, rgb: tuple = DEFAULT_TEXT_COLOR):
        if layout not in LAYOUTS:
            raise HaloError("未知布局: %s" % layout)
        scroll, mode = LAYOUTS[layout]
        payload = [0x01, rgb[0] & 0xFF, rgb[1] & 0xFF, rgb[2] & 0xFF, 0x00, 0x02, scroll, mode, 0xFF]
        self.send(CMD_UI, bytes(payload))

    def set_color(self, rgb: tuple):
        r, g, b = (rgb[0] & 0xFF, rgb[1] & 0xFF, rgb[2] & 0xFF)
        payload = [0x03, r, g, b, 0x00, 0x00, 0xFF, 0xFF, 0xFF]
        self.send(CMD_UI, bytes(payload))

    def set_scene(self, scene: str, template: int = 0, rgb: tuple = DEFAULT_TEXT_COLOR):
        if scene not in SCENES:
            raise HaloError("未知场景: %s" % scene)
        payload = [0x02, rgb[0] & 0xFF, rgb[1] & 0xFF, rgb[2] & 0xFF, 0x00, 0x01, SCENES[scene], template & 0xFF, 0xFF]
        self.send(CMD_UI, bytes(payload))

    def query_text(self, timeout_ms: int = 600):
        """回读当前屏幕文本（调试用）"""
        with self._lock:
            if self._dev is None:
                self._open()
            # 先清空遗留缓冲
            try:
                for _ in range(16):
                    if not self._dev.read(PACKET_LEN, 2):
                        break
            except Exception:
                pass
            self._dev.write(build_packet(CMD_TEXT_QUERY, bytes([0x00])))
            resp = self._dev.read(PACKET_LEN, timeout_ms)
            # 排空
            try:
                for _ in range(16):
                    if not self._dev.read(PACKET_LEN, 2):
                        break
            except Exception:
                pass
        rb = bytes(resp) if resp else b""
        if len(rb) > 6 and rb[3] == CMD_TEXT_QUERY:
            plen = (rb[4] << 8) | rb[5]
            payload = rb[6:6 + plen]
            if len(payload) > 4:
                tl = payload[3]
                try:
                    return payload[4:4 + tl].decode("utf-8", "replace")
                except Exception:
                    pass
        return None

    def restore_clock(self, rgb: tuple = DEFAULT_TEXT_COLOR):
        """退出时恢复：主题色 + 时钟场景"""
        try:
            self.set_color(rgb)
            time.sleep(0.03)
            self.set_scene("clock", 0, rgb)
        except Exception:
            pass

    def close(self):
        with self._lock:
            self._close()
